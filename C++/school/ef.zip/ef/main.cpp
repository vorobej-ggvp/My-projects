#include <iostream>
#include <fstream>

using namespace std;

struct eilute1
{
    string kodas;
    double rezultatas[100];
};

void skaityti(eilute1 sarasas[], int &n);

int main()
{
    eilute1 sarasas[100];
    int n;
    skaityti(sarasas, n);
    cout << n;
    for(int i = 0; i < n; i++)
    {
        cout << sarasas[i].kodas << " ";
        for(int j = 0; j < sarasas[i].kodas; j++)
        {
            cout << sarasas[i].rezultatas[j] << endl;
        }
    }
    return 0;
}

//-------------------------------------------------

void skaityti(eilute1 sarasas[], int &n)
{
    ifstream f1("in1.txt");
    f1 >> n;
    for(int i = 0; i < n; i++)
    {
        f1 >> sarasas[i].kodas;
        for(int j = 0; j < sarasas[i].kodas; j++)
        {
            f1 >> sarasas[i].rezultatas[j];
        }
    }
    f1.close();
}
